package org.gradle.wrapper;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Minimal project-local Gradle bootstrapper used when the standard wrapper JAR
 * cannot be provisioned. It reads gradle-wrapper.properties, downloads the pinned
 * Gradle distribution on demand, and forwards command-line arguments to Gradle.
 */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path jar = Path.of(GradleWrapperMain.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI()).toAbsolutePath();
        Path wrapperDir = jar.getParent();
        Path projectDir = wrapperDir.getParent().getParent();
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(wrapperDir.resolve("gradle-wrapper.properties"))) {
            props.load(in);
        }
        String distributionUrl = props.getProperty("distributionUrl");
        if (distributionUrl == null || !distributionUrl.startsWith("https://")) {
            throw new IllegalStateException("A valid HTTPS distributionUrl is required in gradle-wrapper.properties.");
        }
        String fileName = Path.of(URI.create(distributionUrl).getPath()).getFileName().toString();
        String distributionName = fileName.endsWith("-bin.zip")
                ? fileName.substring(0, fileName.length() - "-bin.zip".length()) : fileName.replace(".zip", "");
        String gradleHome = System.getenv("GRADLE_USER_HOME");
        Path cache = (gradleHome == null || gradleHome.isBlank())
                ? Path.of(System.getProperty("user.home"), ".gradle")
                : Path.of(gradleHome);
        Path distributionRoot = cache.resolve("wrapper").resolve("dists")
                .resolve(distributionName + "-bin").resolve("turbank");
        Path gradleHomePath = distributionRoot.resolve(distributionName);
        Path executable = gradleHomePath.resolve("bin").resolve(isWindows() ? "gradle.bat" : "gradle");
        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(distributionRoot);
            Path archive = distributionRoot.resolve(fileName + ".part");
            download(distributionUrl, archive);
            unzipSafely(archive, distributionRoot);
            Files.deleteIfExists(archive);
        }
        if (!Files.isRegularFile(executable)) {
            throw new IOException("Gradle distribution extracted, but no executable was found at " + executable);
        }
        if (!isWindows()) executable.toFile().setExecutable(true, false);
        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add(System.getenv().getOrDefault("COMSPEC", "cmd.exe"));
            command.add("/c");
        }
        command.add(executable.toString());
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command).directory(Path.of("").toAbsolutePath().toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static void download(String url, Path destination) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
        connection.setConnectTimeout(20_000);
        connection.setReadTimeout(60_000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "TUR-BANK-Gradle-Bootstrap/1.0");
        int status = connection.getResponseCode();
        if (status < 200 || status >= 300) {
            connection.disconnect();
            throw new IOException("Unable to download Gradle distribution (HTTP " + status + ").");
        }
        try (InputStream in = new BufferedInputStream(connection.getInputStream());
             OutputStream out = Files.newOutputStream(destination)) {
            byte[] buffer = new byte[32 * 1024];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        } finally {
            connection.disconnect();
        }
    }

    private static void unzipSafely(Path archive, Path destination) throws IOException {
        Path normalizedDestination = destination.toAbsolutePath().normalize();
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(Files.newInputStream(archive)))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                Path output = normalizedDestination.resolve(entry.getName()).normalize();
                if (!output.startsWith(normalizedDestination)) throw new IOException("Invalid path in Gradle ZIP archive.");
                if (entry.isDirectory()) Files.createDirectories(output);
                else {
                    Files.createDirectories(output.getParent());
                    Files.copy(zip, output, StandardCopyOption.REPLACE_EXISTING);
                }
                zip.closeEntry();
            }
        } catch (AtomicMoveNotSupportedException ignored) {
            // The ZIP entries are extracted directly into the user-controlled Gradle cache.
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }
}
