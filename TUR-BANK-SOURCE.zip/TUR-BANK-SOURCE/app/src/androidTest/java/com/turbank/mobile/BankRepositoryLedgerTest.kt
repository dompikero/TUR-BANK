package com.turbank.mobile

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.turbank.mobile.data.AccountEntity
import com.turbank.mobile.data.BankDatabase
import com.turbank.mobile.data.BankRepository
import com.turbank.mobile.data.SavingsGoalEntity
import com.turbank.mobile.data.TransferResult
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BankRepositoryLedgerTest {
    private lateinit var db: BankDatabase
    private lateinit var repository: BankRepository

    @Before
    fun createDatabase() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, BankDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = BankRepository(db)
    }

    @After
    fun closeDatabase() {
        db.close()
    }

    @Test
    fun ownTransferUpdatesBothAccountsAndRepeatedOperationIsRejected() = runBlocking {
        db.accounts().insert(AccountEntity(id = "checking", name = "Checking", type = "EVERYDAY", balanceMinor = 10_000))
        db.accounts().insert(AccountEntity(id = "savings", name = "Savings", type = "SAVINGS", balanceMinor = 2_000))

        val first = repository.transfer("operation-1", "checking", "savings", "", 3_000, "Test move")
        assertTrue(first is TransferResult.Success)
        assertEquals(7_000L, db.accounts().getById("checking")?.balanceMinor)
        assertEquals(5_000L, db.accounts().getById("savings")?.balanceMinor)

        val duplicate = repository.transfer("operation-1", "checking", "savings", "", 3_000, "Test move")
        assertTrue(duplicate is TransferResult.Failure)
        assertEquals(7_000L, db.accounts().getById("checking")?.balanceMinor)
        assertEquals(5_000L, db.accounts().getById("savings")?.balanceMinor)
    }

    @Test
    fun savingsContributionMovesValueAtomically() = runBlocking {
        db.accounts().insert(AccountEntity(id = "checking", name = "Checking", type = "EVERYDAY", balanceMinor = 10_000))
        db.goals().insert(SavingsGoalEntity(id = "trip", name = "Trip", targetMinor = 20_000, savedMinor = 1_000))

        val result = repository.contributeToGoal("trip", "checking", 2_500)
        assertTrue(result is TransferResult.Success)
        assertEquals(7_500L, db.accounts().getById("checking")?.balanceMinor)
        assertEquals(3_500L, db.goals().getById("trip")?.savedMinor)
    }

    @Test
    fun resetDemoDataRestoresSeedAccountsAndRemovesLocalAdditions() = runBlocking {
        db.accounts().insert(AccountEntity(id = "temporary", name = "Temporary", type = "EVERYDAY", balanceMinor = 1_000))
        repository.resetDemoData()
        val accounts = db.accounts().getAll()
        assertEquals(3, accounts.size)
        assertTrue(accounts.none { it.id == "temporary" })
        assertTrue(db.accounts().getById("seed-everyday") != null)
        assertTrue(db.transactions().getById("seed-tx-1") != null)
    }

    @Test
    fun insufficientBalanceLeavesLedgerUnchanged() = runBlocking {
        db.accounts().insert(AccountEntity(id = "checking", name = "Checking", type = "EVERYDAY", balanceMinor = 100))
        db.accounts().insert(AccountEntity(id = "savings", name = "Savings", type = "SAVINGS", balanceMinor = 0))

        val result = repository.transfer("operation-2", "checking", "savings", "", 500, "Too large")
        assertTrue(result is TransferResult.Failure)
        assertEquals(100L, db.accounts().getById("checking")?.balanceMinor)
        assertEquals(0L, db.accounts().getById("savings")?.balanceMinor)
    }
}
