package com.turbank.mobile.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TransferRulesTest {
    @Test fun validOwnTransferPasses() {
        assertNull(TransferRules.validate("a", "b", "EUR", "EUR", 20_000, 5_000, 0, "Savings"))
    }

    @Test fun preventsSendingMoreThanAvailableIncludingFee() {
        assertEquals("insufficient_funds", TransferRules.validate("a", null, "EUR", null, 10_000, 9_990, 20, "Sam"))
    }

    @Test fun rejectsSameAccountAndCurrencyMismatch() {
        assertEquals("same_account", TransferRules.validate("a", "a", "EUR", "EUR", 20_000, 100, 0, "A"))
        assertEquals("currency_mismatch", TransferRules.validate("a", "b", "EUR", "USD", 20_000, 100, 0, "B"))
    }

    @Test fun rejectsMissingRecipientAndInvalidAmount() {
        assertEquals("recipient_missing", TransferRules.validate("a", null, "EUR", null, 20_000, 100, 0, "  "))
        assertEquals("invalid_amount", TransferRules.validate("a", null, "EUR", null, 20_000, 0, 0, "Sam"))
    }
}
