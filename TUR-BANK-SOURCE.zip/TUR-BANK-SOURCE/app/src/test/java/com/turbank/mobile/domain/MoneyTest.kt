package com.turbank.mobile.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MoneyTest {
    @Test fun parsesDecimalMoneyIntoMinorUnits() {
        assertEquals(12345L, Money.parseMinorUnits("123.45"))
        assertEquals(12345L, Money.parseMinorUnits("123,45"))
        assertEquals(100L, Money.parseMinorUnits("1"))
        assertNull(Money.parseMinorUnits("0"))
        assertNull(Money.parseMinorUnits("-1.00"))
        assertNull(Money.parseMinorUnits("not-a-number"))
    }

    @Test fun loanCalculatorHandlesZeroInterestAndPositiveInterest() {
        assertEquals(10_000L, Money.loanMonthlyPayment(120_000L, 0.0, 12))
        assertTrue(Money.loanMonthlyPayment(120_000L, 5.0, 12) > 10_000L)
    }

    @Test fun savingsCalculatorHasDeterministicResults() {
        assertEquals(120_000L, Money.savingsFutureValue(10_000L, 0.0, 12))
        assertTrue(Money.savingsFutureValue(10_000L, 5.0, 12) > 120_000L)
    }

    @Test fun progressIsBounded() {
        assertEquals(0f, Money.percent(10, 0), 0.0001f)
        assertEquals(1f, Money.percent(200, 100), 0.0001f)
        assertEquals(0.5f, Money.percent(50, 100), 0.0001f)
    }
}
