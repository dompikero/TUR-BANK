package com.turbank.mobile.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Navy = Color(0xFF101C3C)
private val NavyLight = Color(0xFF23365F)
private val Gold = Color(0xFFD7B979)
private val Pale = Color(0xFFF4F6FA)
private val Dark = Color(0xFF0A1020)
private val Muted = Color(0xFF79849B)

private val LightColors = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    secondary = Gold,
    onSecondary = Navy,
    background = Pale,
    onBackground = Navy,
    surface = Color.White,
    onSurface = Navy,
    surfaceVariant = Color(0xFFE9EDF5),
    onSurfaceVariant = Muted,
    error = Color(0xFFB3261E)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFBBC9F2),
    onPrimary = Navy,
    secondary = Gold,
    onSecondary = Navy,
    background = Dark,
    onBackground = Color(0xFFF4F6FF),
    surface = Color(0xFF141E32),
    onSurface = Color(0xFFF4F6FF),
    surfaceVariant = Color(0xFF263149),
    onSurfaceVariant = Color(0xFFB0BBD0),
    error = Color(0xFFFFB4AB)
)

@Composable
fun TurBankTheme(theme: String, content: @Composable () -> Unit) {
    val dark = when (theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
