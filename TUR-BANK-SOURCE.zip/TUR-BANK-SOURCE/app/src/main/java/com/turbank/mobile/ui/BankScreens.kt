package com.turbank.mobile.ui

import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.turbank.mobile.BankViewModel
import com.turbank.mobile.R
import com.turbank.mobile.data.AccountEntity
import com.turbank.mobile.data.AppNotificationEntity
import com.turbank.mobile.data.BillEntity
import com.turbank.mobile.data.BudgetEntity
import com.turbank.mobile.data.SavingsGoalEntity
import com.turbank.mobile.data.TransactionEntity
import com.turbank.mobile.data.UserSettings
import com.turbank.mobile.data.VirtualCardEntity
import com.turbank.mobile.domain.Money
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToLong

private val CardRadius = RoundedCornerShape(22.dp)

@Composable
fun LanguageSelectionScreen(onChoose: (String) -> Unit) {
    var selected by remember { mutableStateOf("en") }
    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) {
            Text("T", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(28.dp))
        Text(stringResource(R.string.language_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.language_subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        listOf("tr" to "Türkçe", "en" to "English", "de" to "Deutsch").forEach { (code, label) ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { selected = code },
                shape = CardRadius,
                colors = CardDefaults.cardColors(containerColor = if (selected == code) MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface),
                border = BorderStroke(if (selected == code) 2.dp else 1.dp, if (selected == code) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    RadioButton(selected = selected == code, onClick = { selected = code })
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = { onChoose(selected) }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
            Text(stringResource(R.string.continue_label))
        }
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.ledger_notice), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(72.dp).clip(RoundedCornerShape(22.dp))
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) { Text("T", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black) }
        Spacer(Modifier.height(28.dp))
        Text(stringResource(R.string.welcome_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.welcome_subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Card(shape = CardRadius) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(stringResource(R.string.demo_user), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.fictional_profile), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text(stringResource(R.string.demo_login))
        }
        Spacer(Modifier.height(14.dp))
        Text(stringResource(R.string.about_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.demo_warning), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun DemoLockScreen(showBiometric: Boolean, onUnlock: () -> Unit, onBiometricUnlock: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(20.dp))
        Text(stringResource(R.string.welcome_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.demo_pin), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(4); wrong = false },
            label = { Text(stringResource(R.string.pin)) }, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        if (wrong) Text(stringResource(R.string.wrong_pin), color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { if (pin == "2468") onUnlock() else wrong = true },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(stringResource(R.string.continue_label)) }
        if (showBiometric) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onBiometricUnlock, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.unlock_biometrics)) }
            Text(stringResource(R.string.biometric_fallback), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.ledger_notice), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private data class BottomItem(val route: String, val label: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainBankNavigation(vm: BankViewModel) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "home"
    val settings by vm.settings.collectAsState()
    val message by vm.message.collectAsState()
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(message = localizeMessage(it))
            vm.dismissMessage()
        }
    }

    val title = when (route) {
        "home" -> stringResource(R.string.home)
        "accounts" -> stringResource(R.string.accounts)
        "transfer" -> stringResource(R.string.transfer)
        "activity" -> stringResource(R.string.transactions)
        "insights" -> stringResource(R.string.insights)
        "goals" -> stringResource(R.string.goals)
        "bills" -> stringResource(R.string.bills)
        "cards" -> stringResource(R.string.cards)
        "tools" -> stringResource(R.string.tools)
        "receive" -> stringResource(R.string.receive_demo)
        "notifications" -> stringResource(R.string.notifications)
        else -> stringResource(R.string.settings)
    }
    val bottomItems = listOf(
        BottomItem("home", R.string.home, Icons.Default.Home),
        BottomItem("accounts", R.string.accounts, Icons.Default.AccountBalanceWallet),
        BottomItem("transfer", R.string.transfer, Icons.Default.Send),
        BottomItem("activity", R.string.transactions, Icons.Default.ReceiptLong),
        BottomItem("settings", R.string.settings, Icons.Default.Settings)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(title, fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.demo_warning), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                    }
                },
                actions = {
                    IconButton(onClick = { nav.navigate("notifications") { launchSingleTop = true } }) {
                        Icon(Icons.Default.Tune, contentDescription = stringResource(R.string.notifications))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                bottomItems.forEach { item ->
                    NavigationBarItem(
                        selected = route == item.route,
                        onClick = { nav.navigate(item.route) { launchSingleTop = true; restoreState = true } },
                        icon = { Icon(item.icon, contentDescription = stringResource(item.label)) },
                        label = { Text(stringResource(item.label), maxLines = 1) }
                    )
                }
            }
        }
    ) { inner ->
        NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(inner)) {
            composable("home") { HomeScreen(vm, nav, settings) }
            composable("accounts") { AccountsScreen(vm, settings) }
            composable("transfer") { TransferScreen(vm, settings) }
            composable("activity") { TransactionsScreen(vm, settings) }
            composable("insights") { InsightsScreen(vm, settings) }
            composable("goals") { GoalsScreen(vm, settings) }
            composable("bills") { BillsScreen(vm, settings) }
            composable("cards") { CardsScreen(vm, settings) }
            composable("tools") { ToolsScreen(settings) }
            composable("receive") { ReceiveScreen(vm, settings) }
            composable("notifications") { NotificationsScreen(vm, settings) }
            composable("settings") { SettingsScreen(vm, settings) }
        }
    }
}

@Composable
private fun localizeMessage(code: String): String = when (code) {
    "transfer_success" -> stringResource(R.string.transfer_success)
    "insufficient_funds" -> stringResource(R.string.insufficient_funds)
    "invalid_amount" -> stringResource(R.string.invalid_amount)
    "saved" -> stringResource(R.string.msg_saved)
    "account_created" -> stringResource(R.string.msg_account_created)
    "invalid_input" -> stringResource(R.string.msg_invalid_input)
    "duplicate" -> stringResource(R.string.msg_duplicate)
    "source_missing" -> stringResource(R.string.msg_source_missing)
    "destination_missing" -> stringResource(R.string.msg_destination_missing)
    "same_account" -> stringResource(R.string.msg_same_account)
    "currency_mismatch" -> stringResource(R.string.msg_currency_mismatch)
    "recipient_missing" -> stringResource(R.string.msg_recipient_missing)
    "goal_missing" -> stringResource(R.string.msg_goal_missing)
    "goal_insufficient" -> stringResource(R.string.msg_goal_insufficient)
    "bill_missing" -> stringResource(R.string.msg_bill_missing)
    "already_paid" -> stringResource(R.string.msg_already_paid)
    "reset_done" -> stringResource(R.string.msg_reset_done)
    "card_frozen" -> stringResource(R.string.msg_card_frozen)
    "card_payment_disabled" -> stringResource(R.string.msg_card_payment_disabled)
    "card_limit" -> stringResource(R.string.msg_card_limit)
    "merchant_required" -> stringResource(R.string.msg_merchant_required)
    "purchase_success" -> stringResource(R.string.purchase_success)
    "receive_success" -> stringResource(R.string.receive_success)
    else -> stringResource(R.string.msg_generic_error)
}

@Composable
private fun HomeScreen(vm: BankViewModel, nav: NavHostController, settings: UserSettings) {
    val accounts by vm.accounts.collectAsState()
    val recent by vm.recentTransactions.collectAsState()
    val showBalances = settings.showBalances
    val currencyAccounts = accounts.filter { it.currencyCode == settings.displayCurrency }
    val total = currencyAccounts.sumOf { it.balanceMinor }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth().animateContentSize(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Box(Modifier.background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, Color(0xFF344A78)))).padding(22.dp)) {
                Column {
                    Text(stringResource(R.string.total_balance), color = Color.White.copy(alpha = .8f))
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (showBalances) Money.format(total, settings.displayCurrency, settings.language) else "••••••", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        IconButton(onClick = { vm.setShowBalances(!showBalances) }) {
                            Icon(if (showBalances) Icons.Default.Shield else Icons.Default.Wallet, contentDescription = stringResource(if (showBalances) R.string.hide_balance else R.string.show_balance), tint = MaterialTheme.colorScheme.secondary)
                        }
                    }
                    Text("${accounts.size} ${stringResource(R.string.accounts).lowercase()}", color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(18.dp))
                    Text(stringResource(R.string.demo_warning), color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
        SectionHeading(stringResource(R.string.quick_actions))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            QuickAction(Icons.Default.SwapHoriz, stringResource(R.string.send_money), Modifier.weight(1f)) { nav.navigate("transfer") }
            QuickAction(Icons.Default.Analytics, stringResource(R.string.insights), Modifier.weight(1f)) { nav.navigate("insights") }
            QuickAction(Icons.Default.Savings, stringResource(R.string.goals), Modifier.weight(1f)) { nav.navigate("goals") }
            QuickAction(Icons.Default.CreditCard, stringResource(R.string.cards), Modifier.weight(1f)) { nav.navigate("cards") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionHeading(stringResource(R.string.my_accounts), Modifier.weight(1f))
            TextButton(onClick = { nav.navigate("accounts") }) { Text(stringResource(R.string.view_all)) }
        }
        if (accounts.isEmpty()) EmptyState(stringResource(R.string.no_items))
        accounts.take(3).forEach { AccountRow(it, showBalances, settings.language, onClick = { nav.navigate("accounts") }) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionHeading(stringResource(R.string.recent_activity), Modifier.weight(1f))
            TextButton(onClick = { nav.navigate("activity") }) { Text(stringResource(R.string.view_all)) }
        }
        if (recent.isEmpty()) EmptyState(stringResource(R.string.no_transactions))
        recent.take(5).forEach { TransactionRow(it, accounts, showBalances, settings.language, onClick = { nav.navigate("activity") }) }
        SectionHeading(stringResource(R.string.explore))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { nav.navigate("bills") }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.bills)) }
            OutlinedButton(onClick = { nav.navigate("tools") }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.tools)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { nav.navigate("receive") }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.receive_demo)) }
            OutlinedButton(onClick = { nav.navigate("notifications") }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.notifications)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { nav.navigate("settings") }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.settings)) }
            OutlinedButton(onClick = { nav.navigate("cards") }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.cards)) }
        }
        Text(stringResource(R.string.display_currency_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(stringResource(R.string.ledger_notice), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AccountsScreen(vm: BankViewModel, settings: UserSettings) {
    val accounts by vm.accounts.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<AccountEntity?>(null) }
    var rename by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                SectionHeading(stringResource(R.string.my_accounts))
                Text(stringResource(R.string.ledger_notice), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { showAdd = true }) { Text("+ " + stringResource(R.string.add_account)) }
        }
        accounts.forEach { account ->
            AccountRow(account, settings.showBalances, settings.language, onClick = { selected = account; rename = account.name })
        }
        SectionHeading(stringResource(R.string.sample_data))
        Text(stringResource(R.string.account_balance_stored), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (showAdd) AddAccountDialog(onDismiss = { showAdd = false }, onCreate = { name, type, currency ->
        vm.createAccount(name, type, currency); showAdd = false
    })
    selected?.let { account ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(stringResource(R.string.edit) + " · " + account.name) },
            text = { OutlinedTextField(value = rename, onValueChange = { rename = it }, label = { Text(stringResource(R.string.account_name)) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.renameAccount(account.id, rename); selected = null }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { selected = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun AddAccountDialog(onDismiss: () -> Unit, onCreate: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("EVERYDAY") }
    var currency by remember { mutableStateOf("EUR") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_account)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.account_name)) }, singleLine = true)
                Text(stringResource(R.string.account_type), style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("EVERYDAY", "SAVINGS", "SHARED", "FOREIGN").forEach { item ->
                        FilterChip(selected = type == item, onClick = { type = item }, label = { Text(accountTypeLabel(item)) })
                    }
                }
                Text(stringResource(R.string.currency), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("EUR", "USD", "GBP", "TRY").forEach { item ->
                        FilterChip(selected = currency == item, onClick = { currency = item }, label = { Text(item) })
                    }
                }
                Text(stringResource(R.string.demo_warning), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
            }
        },
        confirmButton = { Button(onClick = { onCreate(name, type, currency) }, enabled = name.isNotBlank()) { Text(stringResource(R.string.create)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
private fun TransferScreen(vm: BankViewModel, settings: UserSettings) {
    val accounts by vm.accounts.collectAsState()
    val recipients by vm.recipients.collectAsState()
    val working by vm.working.collectAsState()
    var fromId by remember { mutableStateOf("") }
    var toId by remember { mutableStateOf("") }
    var ownTransfer by remember { mutableStateOf(true) }
    var recipient by remember { mutableStateOf("") }
    var amount by rememberSaveable { mutableStateOf("") }
    var operationId by rememberSaveable { mutableStateOf(java.util.UUID.randomUUID().toString()) }
    var description by remember { mutableStateOf("") }
    var addRecipient by remember { mutableStateOf(false) }
    var confirmation by remember { mutableStateOf(false) }
    LaunchedEffect(accounts) {
        if (fromId.isBlank() && accounts.isNotEmpty()) fromId = accounts.first().id
        if (toId.isBlank() && accounts.size > 1) toId = accounts.first { it.id != fromId }.id
    }
    val from = accounts.firstOrNull { it.id == fromId }
    val destination = accounts.firstOrNull { it.id == toId }
    val minor = Money.parseMinorUnits(amount)
    val fee = if (!ownTransfer && minor != null) minor * 50L / 10_000L else 0L

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        DemoNotice()
        SectionHeading(stringResource(R.string.review_transfer))
        ChoiceField(stringResource(R.string.from_account), accounts.map { it.id to "${it.name} · ${it.currencyCode}" }, fromId, { fromId = it }) 
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = ownTransfer, onClick = { ownTransfer = true }, label = { Text(stringResource(R.string.to_account)) })
            FilterChip(selected = !ownTransfer, onClick = { ownTransfer = false }, label = { Text(stringResource(R.string.recipient)) })
        }
        if (ownTransfer) {
            ChoiceField(
                stringResource(R.string.to_account),
                accounts.filter { it.id != fromId }.map { it.id to "${it.name} · ${it.currencyCode}" },
                toId,
                { toId = it }
            )
            if (from != null && destination != null && from.currencyCode != destination.currencyCode) {
                Text(stringResource(R.string.msg_currency_mismatch), color = MaterialTheme.colorScheme.error)
            }
        } else {
            OutlinedTextField(
                value = recipient, onValueChange = { recipient = it },
                label = { Text(stringResource(R.string.recipient)) }, modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                recipients.forEach { person ->
                    AssistChip(onClick = { recipient = person.name }, label = { Text(person.name) })
                }
                AssistChip(onClick = { addRecipient = true }, label = { Text(stringResource(R.string.save_recipient_action)) })
            }
        }
        OutlinedTextField(
            value = amount, onValueChange = { value ->
                if (amount.isBlank() && value.isNotBlank()) operationId = java.util.UUID.randomUUID().toString()
                amount = value.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(15)
            },
            label = { Text(stringResource(R.string.amount)) }, leadingIcon = { Text(from?.currencyCode ?: "EUR") },
            modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        OutlinedTextField(value = description, onValueChange = { description = it.take(90) }, label = { Text(stringResource(R.string.description)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        if (!ownTransfer && minor != null) {
            SummaryLine(stringResource(R.string.demo_fee), Money.format(fee, from?.currencyCode ?: "EUR", settings.language))
            SummaryLine(stringResource(R.string.total_debit), Money.format(minor + fee, from?.currencyCode ?: "EUR", settings.language), bold = true)
        }
        Button(
            onClick = { confirmation = true },
            enabled = !working && from != null && minor != null && (if (ownTransfer) destination != null && destination.id != from.id && destination.currencyCode == from.currencyCode else recipient.isNotBlank()),
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text(stringResource(R.string.review_transfer)) }
        Text(stringResource(R.string.ledger_notice), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }

    if (addRecipient) {
        var newName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addRecipient = false }, title = { Text(stringResource(R.string.save_recipient)) },
            text = { OutlinedTextField(newName, { newName = it }, label = { Text(stringResource(R.string.recipient)) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.addRecipient(newName); recipient = newName; addRecipient = false }, enabled = newName.isNotBlank()) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { addRecipient = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (confirmation) {
        AlertDialog(
            onDismissRequest = { confirmation = false },
            title = { Text(stringResource(R.string.confirm_transfer)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryLine(stringResource(R.string.from_label), from?.name ?: "—")
                    SummaryLine(stringResource(R.string.to_label), if (ownTransfer) destination?.name ?: "—" else recipient)
                    SummaryLine(stringResource(R.string.amount), minor?.let { Money.format(it, from?.currencyCode ?: "EUR", settings.language) } ?: "—", bold = true)
                    if (!ownTransfer) SummaryLine(stringResource(R.string.demo_fee_label), Money.format(fee, from?.currencyCode ?: "EUR", settings.language))
                    Text(stringResource(R.string.demo_warning), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                Button(onClick = {
                    vm.transfer(fromId, if (ownTransfer) toId else null, recipient, minor, description, operationId)
                    confirmation = false
                    amount = ""
                }, enabled = !working) { Text(stringResource(R.string.confirm_transfer)) }
            },
            dismissButton = { TextButton(onClick = { confirmation = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun TransactionsScreen(vm: BankViewModel, settings: UserSettings) {
    val transactions by vm.transactions.collectAsState()
    val accounts by vm.accounts.collectAsState()
    var query by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("ALL") }
    var range by remember { mutableStateOf("30") }
    var accountFilter by remember { mutableStateOf("ALL") }
    var categoryFilter by remember { mutableStateOf("ALL") }
    var amountFilter by remember { mutableStateOf("ALL") }
    var selected by remember { mutableStateOf<TransactionEntity?>(null) }
    var editing by remember { mutableStateOf<TransactionEntity?>(null) }
    val now = System.currentTimeMillis()
    val filtered = transactions.filter { tx ->
        val matchesQuery = query.isBlank() || listOf(tx.description, tx.recipient, tx.category, tx.note).any { it.contains(query, true) }
        val matchesDirection = direction == "ALL" || tx.direction == direction
        val matchesAccount = accountFilter == "ALL" || tx.accountId == accountFilter
        val matchesCategory = categoryFilter == "ALL" || tx.category == categoryFilter
        val matchesAmount = when (amountFilter) {
            "UNDER_50" -> tx.amountMinor < 5_000L
            "50_200" -> tx.amountMinor in 5_000L..20_000L
            "OVER_200" -> tx.amountMinor > 20_000L
            else -> true
        }
        val rangeMillis = when (range) { "7" -> 7L * 86_400_000; "365" -> 365L * 86_400_000; else -> 30L * 86_400_000 }
        val matchesDate = range == "ALL" || tx.createdAt >= now - rangeMillis
        matchesQuery && matchesDirection && matchesAccount && matchesCategory && matchesAmount && matchesDate
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(query, { query = it }, label = { Text(stringResource(R.string.search_transactions)) }, leadingIcon = { Icon(Icons.Default.ReceiptLong, null) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("ALL" to stringResource(R.string.all), "IN" to stringResource(R.string.income), "OUT" to stringResource(R.string.expenses)).forEach { (value, label) ->
                FilterChip(selected = direction == value, onClick = { direction = value }, label = { Text(label) })
            }
            listOf("7" to "7d", "30" to "30d", "365" to "1y", "ALL" to stringResource(R.string.all_time)).forEach { (value, label) ->
                FilterChip(selected = range == value, onClick = { range = value }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        ChoiceField(
            stringResource(R.string.account_filter),
            listOf("ALL" to stringResource(R.string.all)) + accounts.map { it.id to "${it.name} · ${it.currencyCode}" },
            accountFilter,
            { accountFilter = it }
        )
        val categories = transactions.map { it.category }.distinct().sorted()
        if (categories.isNotEmpty()) {
            Text(stringResource(R.string.category_filter), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (listOf("ALL" to stringResource(R.string.all)) + categories.map { it to it }).forEach { (value, label) ->
                    FilterChip(selected = categoryFilter == value, onClick = { categoryFilter = value }, label = { Text(label) })
                }
            }
        }
        Text(stringResource(R.string.amount_range), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(
                "ALL" to stringResource(R.string.all),
                "UNDER_50" to stringResource(R.string.amount_under_50),
                "50_200" to stringResource(R.string.amount_50_200),
                "OVER_200" to stringResource(R.string.amount_over_200)
            ).forEach { (value, label) ->
                FilterChip(selected = amountFilter == value, onClick = { amountFilter = value }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        if (filtered.isEmpty()) {
            EmptyState(stringResource(R.string.no_transactions))
        } else {
            Text(stringResource(R.string.records, filtered.size), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                filtered.forEach { tx -> TransactionRow(tx, accounts, settings.showBalances, settings.language) { selected = tx } }
            }
        }
    }
    selected?.let { tx ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(tx.description.ifBlank { tx.category }) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryLine(stringResource(R.string.merchant_recipient), tx.recipient)
                    SummaryLine(stringResource(R.string.category), tx.category)
                    SummaryLine(stringResource(R.string.date), DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, localeFor(settings.language)).format(Date(tx.createdAt)))
                    SummaryLine(stringResource(R.string.status), tx.status)
                    SummaryLine(stringResource(R.string.amount), Money.format(tx.amountMinor, accounts.firstOrNull { it.id == tx.accountId }?.currencyCode ?: "EUR", settings.language), bold = true)
                    if (tx.note.isNotBlank()) SummaryLine(stringResource(R.string.notes), tx.note)
                    Text(stringResource(R.string.demo_warning), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { editing = tx; selected = null }) { Text(stringResource(R.string.edit)) }
                    TextButton(onClick = { selected = null }) { Text(stringResource(R.string.close)) }
                }
            }
        )
    }
    editing?.let { tx ->
        var category by remember(tx.id) { mutableStateOf(tx.category) }
        var note by remember(tx.id) { mutableStateOf(tx.note) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(stringResource(R.string.edit) + " · " + tx.description) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(category, { category = it }, label = { Text(stringResource(R.string.category)) }, singleLine = true)
                    OutlinedTextField(note, { note = it }, label = { Text(stringResource(R.string.notes)) }, minLines = 2)
                }
            },
            confirmButton = { Button(onClick = { vm.updateTransaction(tx.copy(category = category, note = note)); editing = null }, enabled = category.isNotBlank()) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun InsightsScreen(vm: BankViewModel, settings: UserSettings) {
    val tx by vm.transactions.collectAsState()
    val accounts by vm.accounts.collectAsState()
    val budgets by vm.budgets.collectAsState()
    var period by remember { mutableStateOf("month") }
    val now = System.currentTimeMillis()
    val monthStart = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.DAY_OF_MONTH, 1)
        set(java.util.Calendar.HOUR_OF_DAY, 0)
        set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis
    val yearStart = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.MONTH, java.util.Calendar.JANUARY)
        set(java.util.Calendar.DAY_OF_MONTH, 1)
        set(java.util.Calendar.HOUR_OF_DAY, 0)
        set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis
    val cutoff = when (period) { "7" -> now - 7L * 86_400_000; "year" -> yearStart; else -> monthStart }
    val periodTx = tx.filter { it.createdAt >= cutoff }
    val filtered = periodTx.filter { item ->
        accounts.firstOrNull { it.id == item.accountId }?.currencyCode == settings.displayCurrency
    }
    val eurTransactions = periodTx.filter { item ->
        accounts.firstOrNull { it.id == item.accountId }?.currencyCode == "EUR"
    }
    val income = filtered.filter { it.direction == "IN" }.sumOf { it.amountMinor }
    val expense = filtered.filter { it.direction == "OUT" }.sumOf { it.amountMinor }
    val byCategory = filtered.filter { it.direction == "OUT" }.groupBy { it.category }
        .mapValues { (_, list) -> list.sumOf { it.amountMinor } }.toList().sortedByDescending { it.second }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("7" to stringResource(R.string.days_7), "month" to stringResource(R.string.this_month), "year" to stringResource(R.string.this_year)).forEach { (value, label) ->
                FilterChip(selected = period == value, onClick = { period = value }, label = { Text(label) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(stringResource(R.string.income), Money.format(income, settings.displayCurrency, settings.language), Icons.Default.ArrowDownward, Modifier.weight(1f))
            MetricCard(stringResource(R.string.expenses), Money.format(expense, settings.displayCurrency, settings.language), Icons.Default.ArrowUpward, Modifier.weight(1f))
        }
        Card(shape = CardRadius) {
            Column(Modifier.padding(16.dp)) {
                SectionHeading(stringResource(R.string.expense_categories))
                Spacer(Modifier.height(12.dp))
                if (byCategory.isEmpty()) EmptyState(stringResource(R.string.no_transactions))
                byCategory.take(8).forEach { (category, value) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(category, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(Money.format(value, settings.displayCurrency, settings.language), fontWeight = FontWeight.SemiBold)
                    }
                    LinearProgressIndicator(progress = { if (expense > 0) (value.toFloat() / expense).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape))
                }
            }
        }
        Card(shape = CardRadius) {
            Column(Modifier.padding(16.dp)) {
                SectionHeading(stringResource(R.string.budget_status))
                Text(stringResource(R.string.budget_currency_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                budgets.forEach { budget ->
                    val spent = eurTransactions.filter { it.direction == "OUT" && it.category.equals(budget.category, true) }.sumOf { it.amountMinor }
                    val progress = Money.percent(spent, budget.limitMinor)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(budget.category, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Text("${(progress * 100).roundToLong()}%")
                    }
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = if (progress >= 1f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    Text("${Money.format(spent, "EUR", settings.language)} / ${Money.format(budget.limitMinor, "EUR", settings.language)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Text(stringResource(R.string.insights_demo_note), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun GoalsScreen(vm: BankViewModel, settings: UserSettings) {
    val goals by vm.goals.collectAsState()
    val accounts by vm.accounts.collectAsState()
    var add by remember { mutableStateOf(false) }
    var actionGoal by remember { mutableStateOf<SavingsGoalEntity?>(null) }
    var withdraw by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionHeading(stringResource(R.string.goals), Modifier.weight(1f))
            Button(onClick = { add = true }) { Text("+ " + stringResource(R.string.add_goal)) }
        }
        if (goals.isEmpty()) EmptyState(stringResource(R.string.no_goals))
        goals.forEach { goal ->
            Card(shape = CardRadius, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Savings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(goal.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(stringResource(R.string.goal_progress, Money.format(goal.savedMinor, goal.currencyCode, settings.language), Money.format(goal.targetMinor, goal.currencyCode, settings.language)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("${(Money.percent(goal.savedMinor, goal.targetMinor) * 100).roundToLong()}%", fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(progress = { Money.percent(goal.savedMinor, goal.targetMinor) }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { actionGoal = goal; withdraw = false }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.contribute)) }
                        OutlinedButton(onClick = { actionGoal = goal; withdraw = true }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.withdraw)) }
                    }
                }
            }
        }
        Text(stringResource(R.string.goal_ledger_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (add) {
        var name by remember { mutableStateOf("") }
        var target by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { add = false }, title = { Text(stringResource(R.string.add_goal)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.goal_name)) }, singleLine = true)
                    OutlinedTextField(target, { target = it }, label = { Text(stringResource(R.string.target_amount)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
            },
            confirmButton = { Button(onClick = { vm.createGoal(name, Money.parseMinorUnits(target), settings.displayCurrency); add = false }, enabled = name.isNotBlank() && Money.parseMinorUnits(target) != null) { Text(stringResource(R.string.create)) } },
            dismissButton = { TextButton(onClick = { add = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    actionGoal?.let { goal ->
        var amount by remember { mutableStateOf("") }
        var source by remember(goal.id) { mutableStateOf(accounts.firstOrNull { it.currencyCode == goal.currencyCode }?.id.orEmpty()) }
        val compatibleAccounts = accounts.filter { it.currencyCode == goal.currencyCode }
        AlertDialog(
            onDismissRequest = { actionGoal = null },
            title = { Text((if (withdraw) stringResource(R.string.withdraw) else stringResource(R.string.contribute)) + " · " + goal.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ChoiceField(stringResource(R.string.from_account), compatibleAccounts.map { it.id to "${it.name} · ${it.currencyCode}" }, source, { source = it })
                    OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' } }, label = { Text(stringResource(R.string.amount)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
            },
            confirmButton = { Button(onClick = { vm.contribute(goal.id, source, Money.parseMinorUnits(amount), withdraw); actionGoal = null }, enabled = Money.parseMinorUnits(amount) != null && source.isNotBlank() && compatibleAccounts.isNotEmpty()) { Text(stringResource(R.string.confirm_transfer)) } },
            dismissButton = { TextButton(onClick = { actionGoal = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun BillsScreen(vm: BankViewModel, settings: UserSettings) {
    val bills by vm.bills.collectAsState()
    val accounts by vm.accounts.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionHeading(stringResource(R.string.bills))
        if (bills.isEmpty()) EmptyState(stringResource(R.string.no_bills))
        bills.forEach { bill ->
            Card(shape = CardRadius) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(bill.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(bill.category + " · " + bill.recurrence.lowercase(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(stringResource(R.string.due_date) + ": " + DateFormat.getDateInstance(DateFormat.MEDIUM, localeFor(settings.language)).format(Date(bill.dueAt)), style = MaterialTheme.typography.bodySmall)
                        }
                        Text(Money.format(bill.amountMinor, bill.currencyCode, settings.language), fontWeight = FontWeight.Bold)
                    }
                    if (bill.paid) {
                        Text(stringResource(R.string.operation_done), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    } else {
                        Button(
                            onClick = {
                                val source = accounts.firstOrNull { it.currencyCode == bill.currencyCode }
                                if (source != null) vm.payBill(bill.id, source.id)
                            },
                            enabled = accounts.any { it.currencyCode == bill.currencyCode },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(stringResource(R.string.mark_paid)) }
                    }
                }
            }
        }
        Text(stringResource(R.string.bills_demo_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun CardsScreen(vm: BankViewModel, settings: UserSettings) {
    val cards by vm.cards.collectAsState()
    val accounts by vm.accounts.collectAsState()
    var adding by remember { mutableStateOf(false) }
    var paymentFor by remember { mutableStateOf<VirtualCardEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<VirtualCardEntity?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionHeading(stringResource(R.string.cards), Modifier.weight(1f))
            Button(onClick = { adding = true }) { Text("+ " + stringResource(R.string.add_card)) }
        }
        if (cards.isEmpty()) EmptyState(stringResource(R.string.no_items))
        cards.forEach { card ->
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, Color(0xFF2E416D)))).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("TUR BANK", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.CreditCard, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    }
                    Text(card.lastFour, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(card.nickname, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(stringResource(R.string.spent_limit) + ": " + Money.format(card.spentMinor, card.currencyCode, settings.language) + " / " + Money.format(card.limitMinor, card.currencyCode, settings.language), color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.bodySmall)
                        }
                        if (card.frozen) Text(stringResource(R.string.frozen_badge), color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            Card(shape = CardRadius) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(stringResource(R.string.card_controls), fontWeight = FontWeight.Bold)
                    SettingSwitch(stringResource(R.string.online_payments), card.onlineEnabled) { vm.updateCard(card.copy(onlineEnabled = it)) }
                    SettingSwitch(stringResource(R.string.contactless), card.contactlessEnabled) { vm.updateCard(card.copy(contactlessEnabled = it)) }
                    SettingSwitch(stringResource(R.string.atm_withdrawals), card.atmEnabled) { vm.updateCard(card.copy(atmEnabled = it)) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { vm.updateCard(card.copy(frozen = !card.frozen)); }, modifier = Modifier.weight(1f)) {
                            Text(stringResource(if (card.frozen) R.string.unfreeze_card else R.string.freeze_card))
                        }
                        Button(onClick = { paymentFor = card }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.simulate_purchase)) }
                    }
                    TextButton(onClick = { deleteTarget = card }) { Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error) }
                }
            }
        }
        Text(stringResource(R.string.card_security_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (adding) {
        var name by remember { mutableStateOf("") }
        var limit by remember { mutableStateOf("500.00") }
        AlertDialog(
            onDismissRequest = { adding = false }, title = { Text(stringResource(R.string.add_card)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.account_name)) }, singleLine = true)
                    OutlinedTextField(limit, { limit = it }, label = { Text(stringResource(R.string.spending_limit)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
            },
            confirmButton = { Button(onClick = { vm.addCard(name, Money.parseMinorUnits(limit)); adding = false }, enabled = name.isNotBlank() && Money.parseMinorUnits(limit) != null) { Text(stringResource(R.string.create)) } },
            dismissButton = { TextButton(onClick = { adding = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    paymentFor?.let { card ->
        var merchant by remember { mutableStateOf("") }
        var amount by remember { mutableStateOf("") }
        var channel by remember { mutableStateOf("ONLINE") }
        val compatibleAccounts = accounts.filter { it.currencyCode == card.currencyCode }
        var accountId by remember(card.id) { mutableStateOf(compatibleAccounts.firstOrNull()?.id.orEmpty()) }
        AlertDialog(
            onDismissRequest = { paymentFor = null },
            title = { Text(stringResource(R.string.simulate_purchase) + " · " + card.nickname) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedTextField(merchant, { merchant = it }, label = { Text(stringResource(R.string.merchant)) }, singleLine = true)
                    OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' } }, label = { Text(stringResource(R.string.amount)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                    ChoiceField(stringResource(R.string.from_account), compatibleAccounts.map { it.id to "${it.name} · ${it.currencyCode}" }, accountId, { accountId = it })
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("ONLINE" to stringResource(R.string.online), "CONTACTLESS" to stringResource(R.string.contactless), "ATM" to stringResource(R.string.atm_withdrawals)).forEach { (id, label) ->
                            FilterChip(selected = channel == id, onClick = { channel = id }, label = { Text(label) })
                        }
                    }
                }
            },
            confirmButton = { Button(onClick = { vm.simulateCardPayment(card.id, accountId, Money.parseMinorUnits(amount), merchant, channel); paymentFor = null }, enabled = merchant.isNotBlank() && Money.parseMinorUnits(amount) != null && accountId.isNotBlank() && compatibleAccounts.isNotEmpty()) { Text(stringResource(R.string.confirm_transfer)) } },
            dismissButton = { TextButton(onClick = { paymentFor = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    deleteTarget?.let { card ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null }, title = { Text(stringResource(R.string.delete) + " · " + card.nickname) },
            text = { Text(stringResource(R.string.delete_card_confirmation)) },
            confirmButton = { TextButton(onClick = { vm.deleteCard(card.id); deleteTarget = null }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun ToolsScreen(settings: UserSettings) {
    var amount by remember { mutableStateOf("100.00") }
    var from by remember { mutableStateOf("EUR") }
    var to by remember { mutableStateOf("USD") }
    var converted by remember { mutableStateOf<Double?>(null) }
    val sampleRates = mapOf("EUR" to 1.0, "USD" to 1.08, "GBP" to 0.84, "TRY" to 37.0)
    var principal by remember { mutableStateOf("10000.00") }
    var annual by remember { mutableStateOf("5") }
    var months by remember { mutableStateOf("36") }
    var payment by remember { mutableStateOf<Long?>(null) }
    var monthlySave by remember { mutableStateOf("100.00") }
    var returnRate by remember { mutableStateOf("3") }
    var saveMonths by remember { mutableStateOf("24") }
    var futureValue by remember { mutableStateOf<Long?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(shape = CardRadius) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeading(stringResource(R.string.currency_converter))
                OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' } }, label = { Text(stringResource(R.string.amount)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CurrencyChips(stringResource(R.string.from_currency), from, { from = it }, Modifier.weight(1f))
                    CurrencyChips(stringResource(R.string.to_currency), to, { to = it }, Modifier.weight(1f))
                }
                Button(onClick = {
                    val number = amount.replace(",", ".").toDoubleOrNull()
                    converted = if (number == null) null else number / (sampleRates[from] ?: 1.0) * (sampleRates[to] ?: 1.0)
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.convert)) }
                converted?.let { Text("%.2f %s".format(Locale.US, it, to), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                Text(stringResource(R.string.offline_rates), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(shape = CardRadius) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                SectionHeading(stringResource(R.string.loan_calculator))
                OutlinedTextField(principal, { principal = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' } }, label = { Text(stringResource(R.string.amount)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(annual, { annual = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' } }, label = { Text(stringResource(R.string.annual_rate)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(months, { months = it.filter(Char::isDigit).take(3) }, label = { Text(stringResource(R.string.months)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val p = Money.parseMinorUnits(principal) ?: 0L
                    val rate = annual.replace(",", ".").toDoubleOrNull() ?: 0.0
                    payment = Money.loanMonthlyPayment(p, rate, months.toIntOrNull() ?: 0)
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.calculate)) }
                payment?.let { SummaryLine(stringResource(R.string.monthly_payment), Money.format(it, settings.displayCurrency, settings.language), true) }
                Text(stringResource(R.string.loan_assumption_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(shape = CardRadius) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                SectionHeading(stringResource(R.string.savings_calculator))
                OutlinedTextField(monthlySave, { monthlySave = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' } }, label = { Text(stringResource(R.string.monthly_contribution)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(returnRate, { returnRate = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' || ch == '-' } }, label = { Text(stringResource(R.string.expected_rate)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(saveMonths, { saveMonths = it.filter(Char::isDigit).take(3) }, label = { Text(stringResource(R.string.months)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    futureValue = Money.savingsFutureValue(
                        Money.parseMinorUnits(monthlySave) ?: 0L,
                        returnRate.replace(",", ".").toDoubleOrNull() ?: 0.0,
                        saveMonths.toIntOrNull() ?: 0
                    )
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.calculate)) }
                futureValue?.let { SummaryLine(stringResource(R.string.estimated_value), Money.format(it, settings.displayCurrency, settings.language), true) }
                Text(stringResource(R.string.savings_projection_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}


@Composable
private fun ReceiveScreen(vm: BankViewModel, settings: UserSettings) {
    val accounts by vm.accounts.collectAsState()
    val working by vm.working.collectAsState()
    var accountId by rememberSaveable { mutableStateOf("") }
    var amount by rememberSaveable { mutableStateOf("25.00") }
    var reference by rememberSaveable { mutableStateOf(java.util.UUID.randomUUID().toString().take(8).uppercase()) }
    LaunchedEffect(accounts) {
        if (accountId.isBlank() && accounts.isNotEmpty()) accountId = accounts.first().id
    }
    val account = accounts.firstOrNull { it.id == accountId }
    val amountMinor = Money.parseMinorUnits(amount)
    val payload = "TURBANK-DEMO|ACCOUNT=${account?.id ?: "none"}|CURRENCY=${account?.currencyCode ?: "EUR"}|AMOUNT_MINOR=${amountMinor ?: 0L}|REFERENCE=$reference"
    val qr = remember(payload) { createQrBitmap(payload) }
    val context = LocalContext.current
    val chooserTitle = stringResource(R.string.share_demo_data)
    val demoSender = stringResource(R.string.demo_sender)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        DemoNotice()
        SectionHeading(stringResource(R.string.receive_demo))
        Text(stringResource(R.string.qr_demo_info), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        ChoiceField(stringResource(R.string.to_account), accounts.map { it.id to "${it.name} · ${it.currencyCode}" }, accountId, { accountId = it })
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(15) },
            label = { Text(stringResource(R.string.amount)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        if (qr != null) {
            Card(Modifier.fillMaxWidth(), shape = CardRadius) {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Image(qr.asImageBitmap(), contentDescription = stringResource(R.string.qr_alt), modifier = Modifier.size(210.dp).clip(RoundedCornerShape(12.dp)))
                    SummaryLine(stringResource(R.string.reference), reference)
                    Text(stringResource(R.string.manual_demo_note), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { reference = java.util.UUID.randomUUID().toString().take(8).uppercase() },
                modifier = Modifier.weight(1f)
            ) { Text(stringResource(R.string.regenerate_reference)) }
            Button(
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("TUR BANK demo payment", payload))
                },
                modifier = Modifier.weight(1f)
            ) { Text(stringResource(R.string.copy_demo_data)) }
        }
        OutlinedButton(
            onClick = {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, payload)
                }
                context.startActivity(Intent.createChooser(intent, chooserTitle))
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(stringResource(R.string.share_demo_data)) }
        Divider()
        SectionHeading(stringResource(R.string.credit_demo_money))
        Text(stringResource(R.string.receive_demo_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(
            onClick = { if (account != null) vm.receiveDemoMoney(account.id, amountMinor, demoSender, "Simulated incoming demo payment") },
            enabled = !working && account != null && amountMinor != null,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(stringResource(R.string.credit_demo_money)) }
    }
}

private fun createQrBitmap(contents: String): Bitmap? = runCatching {
    val size = 420
    val hints = mapOf(
        EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
        EncodeHintType.MARGIN to 1
    )
    val matrix = MultiFormatWriter().encode(contents, BarcodeFormat.QR_CODE, size, size, hints)
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    for (x in 0 until size) {
        for (y in 0 until size) {
            bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
    bitmap
}.getOrNull()

@Composable
private fun NotificationsScreen(vm: BankViewModel, settings: UserSettings) {
    val notifications by vm.notifications.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionHeading(stringResource(R.string.notifications))
        if (!settings.notificationsEnabled) {
            EmptyState(stringResource(R.string.notifications_disabled_note))
        } else if (notifications.isEmpty()) EmptyState(stringResource(R.string.no_items))
        else notifications.forEach { notice ->
            NotificationRow(notice) { vm.markNotificationRead(notice.id) }
        }
    }
}

@Composable
private fun SettingsScreen(vm: BankViewModel, settings: UserSettings) {
    val transactions by vm.transactions.collectAsState()
    val accounts by vm.accounts.collectAsState()
    val context = LocalContext.current
    var confirmReset by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var exportError by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            val result = runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                    writer.appendLine("id,created_at,direction,amount_minor,currency,category,recipient,description,status")
                    transactions.forEach { tx ->
                        val accountCurrency = accounts.firstOrNull { it.id == tx.accountId }?.currencyCode ?: "EUR"
                        val values = listOf(tx.id, tx.createdAt.toString(), tx.direction, tx.amountMinor.toString(), accountCurrency, tx.category, tx.recipient, tx.description, tx.status)
                        writer.appendLine(values.joinToString(",") { csvEscape(it) })
                    }
                } ?: error("Unable to open selected destination")
            }
            exportError = result.isFailure
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(shape = CardRadius) {
            Column(Modifier.padding(16.dp)) {
                Text(stringResource(R.string.profile), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(stringResource(R.string.demo_user), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(R.string.local_profile_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        SectionHeading(stringResource(R.string.settings))
        Card(shape = CardRadius) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(stringResource(R.string.theme), fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("system" to stringResource(R.string.theme_system), "light" to stringResource(R.string.theme_light), "dark" to stringResource(R.string.theme_dark)).forEach { (id, label) ->
                        FilterChip(selected = settings.theme == id, onClick = { vm.setTheme(id) }, label = { Text(label) })
                    }
                }
                HorizontalDivider()
                Text(stringResource(R.string.language), fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("tr" to "Türkçe", "en" to "English", "de" to "Deutsch").forEach { (id, label) ->
                        FilterChip(selected = settings.language == id, onClick = { vm.setLanguage(id) }, label = { Text(label) })
                    }
                }
                HorizontalDivider()
                Text(stringResource(R.string.display_currency), fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("EUR", "USD", "GBP", "TRY").forEach { code ->
                        FilterChip(selected = settings.displayCurrency == code, onClick = { vm.setCurrency(code) }, label = { Text(code) })
                    }
                }
            }
        }
        Card(shape = CardRadius) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                SettingSwitch(stringResource(R.string.balance_visibility), settings.showBalances) { vm.setShowBalances(it) }
                SettingSwitch(stringResource(R.string.notifications), settings.notificationsEnabled) { vm.setNotifications(it) }
                SettingSwitch(stringResource(R.string.biometrics), settings.biometricPreference) { vm.setBiometrics(it) }
                SettingSwitch(stringResource(R.string.session_lock), settings.lockOnRestart) { vm.setLockOnRestart(it) }
            }
        }
        OutlinedButton(onClick = { exportLauncher.launch("tur-bank-activity.csv") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.export_csv)) }
        if (exportError) Text(stringResource(R.string.export_failed), color = MaterialTheme.colorScheme.error)
        OutlinedButton(onClick = { showAbout = true }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.about)) }
        Button(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text(stringResource(R.string.reset_demo)) }
        Text(stringResource(R.string.about_body), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Text(stringResource(R.string.app_version), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false }, title = { Text(stringResource(R.string.reset_demo)) },
            text = { Text(stringResource(R.string.reset_confirm)) },
            confirmButton = { Button(onClick = { vm.resetDemoData(); confirmReset = false }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text(stringResource(R.string.reset_demo)) } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (showAbout) {
        AlertDialog(onDismissRequest = { showAbout = false }, title = { Text(stringResource(R.string.about)) }, text = { Text(stringResource(R.string.about_body) + "\n\n" + stringResource(R.string.ledger_notice)) }, confirmButton = { TextButton(onClick = { showAbout = false }) { Text(stringResource(R.string.close)) } })
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChanged: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChanged(!checked) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChanged)
    }
}

@Composable
private fun ChoiceField(label: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val labelValue = options.firstOrNull { it.first == selected }?.second ?: options.firstOrNull()?.second.orEmpty()
    Column {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), enabled = options.isNotEmpty()) {
                Text(labelValue.ifBlank { "—" }, modifier = Modifier.weight(1f))
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(text = { Text(option.second) }, onClick = { onSelect(option.first); expanded = false })
                }
            }
        }
    }
}

@Composable
private fun CurrencyChips(label: String, selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            listOf("EUR", "USD", "GBP", "TRY").forEach { code ->
                FilterChip(selected = selected == code, onClick = { onSelect(code) }, label = { Text(code) })
            }
        }
    }
}

@Composable
private fun QuickAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun AccountRow(account: AccountEntity, showBalance: Boolean, language: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = CardRadius, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(account.name, fontWeight = FontWeight.SemiBold)
                Text(accountTypeLabel(account.type) + " · " + account.currencyCode, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Text(if (showBalance) Money.format(account.balanceMinor, account.currencyCode, language) else "••••", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TransactionRow(tx: TransactionEntity, accounts: List<AccountEntity>, showBalance: Boolean, language: String, onClick: () -> Unit) {
    val isIncome = tx.direction == "IN"
    val currency = accounts.firstOrNull { it.id == tx.accountId }?.currencyCode ?: "EUR"
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(if (isIncome) Color(0xFFDCF4E5) else MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Icon(if (isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, contentDescription = null, tint = if (isIncome) Color(0xFF16764A) else MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(tx.recipient, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(tx.description.ifBlank { tx.category }, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                Text(DateFormat.getDateInstance(DateFormat.MEDIUM, localeFor(language)).format(Date(tx.createdAt)), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            }
            Text(
                (if (isIncome) "+" else "−") + if (showBalance) Money.format(tx.amountMinor, currency, language) else "••••",
                color = if (isIncome) Color(0xFF16764A) else MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, shape = CardRadius) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun NotificationRow(item: AppNotificationEntity, onRead: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onRead),
        shape = CardRadius,
        colors = CardDefaults.cardColors(containerColor = if (item.isRead) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.secondary.copy(alpha = .16f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                if (!item.isRead) Text(stringResource(R.string.new_badge), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            Text(item.body, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(item.createdAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SectionHeading(title: String, modifier: Modifier = Modifier) {
    Text(title, modifier = modifier, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun SummaryLine(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Text(value, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
private fun EmptyState(text: String) {
    Card(Modifier.fillMaxWidth(), shape = CardRadius, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .65f))) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Wallet, contentDescription = null, modifier = Modifier.size(28.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DemoNotice() {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.errorContainer).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.demo_warning), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun accountTypeLabel(type: String): String = when (type) {
    "EVERYDAY" -> stringResource(R.string.everyday)
    "SAVINGS" -> stringResource(R.string.savings)
    "SHARED" -> stringResource(R.string.shared)
    "FOREIGN" -> stringResource(R.string.foreign_currency)
    else -> type
}

private fun localeFor(language: String): Locale = when (language) {
    "tr" -> Locale.forLanguageTag("tr-TR")
    "de" -> Locale.GERMANY
    else -> Locale.US
}

private fun csvEscape(raw: String): String = "\"" + raw.replace("\"", "\"\"") + "\""
