package com.turbank.mobile.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Currency
import java.util.Locale
import kotlin.math.pow

object Money {
    fun parseMinorUnits(raw: String): Long? {
        val normalized = raw.trim().replace(" ", "").replace(",", ".")
        if (normalized.isBlank()) return null
        return try {
            val value = BigDecimal(normalized)
            if (value <= BigDecimal.ZERO) return null
            value.setScale(2, RoundingMode.HALF_UP).movePointRight(2).longValueExact()
        } catch (_: Exception) {
            null
        }
    }

    fun format(minor: Long, currencyCode: String, languageTag: String): String {
        val locale = when (languageTag) {
            "tr" -> Locale.forLanguageTag("tr-TR")
            "de" -> Locale.GERMANY
            else -> Locale.US
        }
        return try {
            val formatter = NumberFormat.getCurrencyInstance(locale)
            formatter.currency = Currency.getInstance(currencyCode)
            formatter.minimumFractionDigits = 2
            formatter.maximumFractionDigits = 2
            formatter.format(minor / 100.0)
        } catch (_: Exception) {
            "${currencyCode} %.2f".format(Locale.US, minor / 100.0)
        }
    }

    fun loanMonthlyPayment(principalMinor: Long, annualRatePercent: Double, months: Int): Long {
        if (principalMinor <= 0 || months <= 0) return 0
        val monthlyRate = annualRatePercent.coerceAtLeast(0.0) / 1200.0
        val payment = if (monthlyRate == 0.0) {
            principalMinor.toDouble() / months
        } else {
            val factor = (1 + monthlyRate).pow(months)
            principalMinor * monthlyRate * factor / (factor - 1)
        }
        return payment.toLong().coerceAtLeast(0)
    }

    fun savingsFutureValue(monthlyContributionMinor: Long, annualRatePercent: Double, months: Int): Long {
        if (months <= 0 || monthlyContributionMinor < 0) return 0
        val rate = annualRatePercent.coerceAtLeast(-99.0) / 1200.0
        val factor = if (rate == 0.0) months.toDouble() else ((1 + rate).pow(months) - 1) / rate
        return (monthlyContributionMinor * factor).toLong().coerceAtLeast(0)
    }

    fun percent(part: Long, total: Long): Float =
        if (total <= 0) 0f else (part.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
}
