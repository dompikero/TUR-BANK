package com.turbank.mobile.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY createdAt ASC") fun observeAll(): Flow<List<AccountEntity>>
    @Query("SELECT * FROM accounts ORDER BY createdAt ASC") suspend fun getAll(): List<AccountEntity>
    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1") suspend fun getById(id: String): AccountEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(account: AccountEntity)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertAll(accounts: List<AccountEntity>)
    @Update suspend fun update(account: AccountEntity)
    @Query("UPDATE accounts SET balanceMinor = :balance WHERE id = :id") suspend fun setBalance(id: String, balance: Long): Int
    @Query("DELETE FROM accounts") suspend fun clear()
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY createdAt DESC") fun observeAll(): Flow<List<TransactionEntity>>
    @Query("SELECT * FROM transactions ORDER BY createdAt DESC LIMIT :limit") fun observeRecent(limit: Int): Flow<List<TransactionEntity>>
    @Query("SELECT * FROM transactions WHERE accountId = :accountId ORDER BY createdAt DESC") fun observeForAccount(accountId: String): Flow<List<TransactionEntity>>
    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1") suspend fun getById(id: String): TransactionEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(item: TransactionEntity)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertAll(items: List<TransactionEntity>)
    @Update suspend fun update(item: TransactionEntity)
    @Query("DELETE FROM transactions") suspend fun clear()
}

@Dao
interface RecipientDao {
    @Query("SELECT * FROM recipients ORDER BY name COLLATE NOCASE") fun observeAll(): Flow<List<RecipientEntity>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(item: RecipientEntity)
    @Query("DELETE FROM recipients") suspend fun clear()
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM savings_goals ORDER BY createdAt DESC") fun observeAll(): Flow<List<SavingsGoalEntity>>
    @Query("SELECT * FROM savings_goals WHERE id = :id LIMIT 1") suspend fun getById(id: String): SavingsGoalEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(item: SavingsGoalEntity)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertAll(items: List<SavingsGoalEntity>)
    @Update suspend fun update(item: SavingsGoalEntity)
    @Query("DELETE FROM savings_goals") suspend fun clear()
}

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets ORDER BY category COLLATE NOCASE") fun observeAll(): Flow<List<BudgetEntity>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertAll(items: List<BudgetEntity>)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(item: BudgetEntity)
    @Update suspend fun update(item: BudgetEntity)
    @Query("DELETE FROM budgets") suspend fun clear()
}

@Dao
interface BillDao {
    @Query("SELECT * FROM bills WHERE active = 1 ORDER BY dueAt ASC") fun observeActive(): Flow<List<BillEntity>>
    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1") suspend fun getById(id: String): BillEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertAll(items: List<BillEntity>)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(item: BillEntity)
    @Update suspend fun update(item: BillEntity)
    @Query("DELETE FROM bills") suspend fun clear()
}

@Dao
interface CardDao {
    @Query("SELECT * FROM virtual_cards ORDER BY createdAt DESC") fun observeAll(): Flow<List<VirtualCardEntity>>
    @Query("SELECT * FROM virtual_cards WHERE id = :id LIMIT 1") suspend fun getById(id: String): VirtualCardEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(item: VirtualCardEntity)
    @Update suspend fun update(item: VirtualCardEntity)
    @Query("DELETE FROM virtual_cards WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM virtual_cards") suspend fun clear()
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM app_notifications ORDER BY createdAt DESC") fun observeAll(): Flow<List<AppNotificationEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: AppNotificationEntity)
    @Update suspend fun update(item: AppNotificationEntity)
    @Query("DELETE FROM app_notifications") suspend fun clear()
}

@Database(
    entities = [
        AccountEntity::class, TransactionEntity::class, RecipientEntity::class,
        SavingsGoalEntity::class, BudgetEntity::class, BillEntity::class,
        VirtualCardEntity::class, AppNotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BankDatabase : RoomDatabase() {
    abstract fun accounts(): AccountDao
    abstract fun transactions(): TransactionDao
    abstract fun recipients(): RecipientDao
    abstract fun goals(): GoalDao
    abstract fun budgets(): BudgetDao
    abstract fun bills(): BillDao
    abstract fun cards(): CardDao
    abstract fun notifications(): NotificationDao

    companion object {
        @Volatile private var INSTANCE: BankDatabase? = null
        fun get(context: Context): BankDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, BankDatabase::class.java, "tur-bank-demo.db"
            ).build().also { INSTANCE = it }
        }
    }
}
