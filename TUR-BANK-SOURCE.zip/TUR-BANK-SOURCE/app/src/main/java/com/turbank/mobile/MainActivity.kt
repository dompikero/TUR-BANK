package com.turbank.mobile

import android.os.Bundle
import android.os.Build
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.turbank.mobile.ui.DemoLockScreen
import com.turbank.mobile.ui.LanguageSelectionScreen
import com.turbank.mobile.ui.MainBankNavigation
import com.turbank.mobile.ui.TurBankTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as TURBankApplication
        setContent {
            val vm: BankViewModel = viewModel(factory = BankViewModel.Factory(app.repository, app.preferences))
            val settings by vm.settings.collectAsState()
            var unlocked by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { vm.initialize() }
            LaunchedEffect(settings.language) {
                if (settings.language.isNotBlank()) {
                    AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(settings.language))
                }
            }
            LaunchedEffect(settings.lockOnRestart) {
                if (!settings.lockOnRestart) unlocked = true
            }
            TurBankTheme(settings.theme) {
                when {
                    settings.language.isBlank() -> LanguageSelectionScreen(onChoose = { language ->
                        vm.setLanguage(language)
                        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(language))
                    })
                    !settings.onboardingComplete -> com.turbank.mobile.ui.WelcomeScreen(onContinue = { vm.completeOnboarding() })
                    settings.lockOnRestart && !unlocked -> DemoLockScreen(
                        showBiometric = settings.biometricPreference,
                        onUnlock = { unlocked = true },
                        onBiometricUnlock = { authenticateWithDevice { success ->
                            if (success) unlocked = true
                        } }
                    )
                    else -> MainBankNavigation(vm = vm)
                }
            }
        }
    }

    private fun authenticateWithDevice(onResult: (Boolean) -> Unit) {
        val allowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        }
        if (BiometricManager.from(this).canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) {
            onResult(false)
            return
        }
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onResult(true)
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onResult(false)
                }
                override fun onAuthenticationFailed() {
                    // The system prompt allows another attempt; the demo remains locked.
                }
            }
        )
        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_prompt_title))
            .setSubtitle(getString(R.string.biometric_prompt_subtitle))
            .setAllowedAuthenticators(allowed)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) builder.setNegativeButtonText(getString(R.string.cancel))
        val info = builder.build()
        prompt.authenticate(info)
    }
}
