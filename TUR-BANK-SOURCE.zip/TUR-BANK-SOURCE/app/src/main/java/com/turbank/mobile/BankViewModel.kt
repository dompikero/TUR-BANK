package com.turbank.mobile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.turbank.mobile.data.BankRepository
import com.turbank.mobile.data.PreferencesRepository
import com.turbank.mobile.data.TransferResult
import com.turbank.mobile.data.UserSettings
import com.turbank.mobile.data.VirtualCardEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class BankViewModel(
    private val repository: BankRepository,
    private val preferences: PreferencesRepository
) : ViewModel() {
    val accounts = repository.accounts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val transactions = repository.transactions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val recentTransactions = repository.recentTransactions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val goals = repository.goals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val budgets = repository.budgets.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val bills = repository.bills.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val cards = repository.cards.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val recipients = repository.recipients.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val notifications = repository.notifications.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val settings: StateFlow<UserSettings> = preferences.settings.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings()
    )

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _working = MutableStateFlow(false)
    val working: StateFlow<Boolean> = _working.asStateFlow()
    private var initialized = false

    fun initialize() {
        if (initialized) return
        initialized = true
        viewModelScope.launch {
            try {
                repository.seedIfNeeded()
            } catch (_: Exception) {
                _message.value = "generic_error"
            }
        }
    }

    fun dismissMessage() { _message.value = null }
    fun setLanguage(value: String) = change { preferences.setLanguage(value) }
    fun setTheme(value: String) = change { preferences.setTheme(value) }
    fun setShowBalances(value: Boolean) = change { preferences.setShowBalances(value) }
    fun setCurrency(value: String) = change { preferences.setCurrency(value) }
    fun setNotifications(value: Boolean) = change { preferences.setNotifications(value) }
    fun setBiometrics(value: Boolean) = change { preferences.setBiometrics(value) }
    fun setLockOnRestart(value: Boolean) = change { preferences.setLockOnRestart(value) }
    fun completeOnboarding() = change { preferences.setOnboardingComplete(true) }

    fun createAccount(name: String, type: String, currency: String = "EUR") = perform {
        if (repository.createAccount(name, type, currency)) "account_created" else "invalid_input"
    }

    fun renameAccount(id: String, name: String) = perform {
        if (repository.renameAccount(id, name)) "saved" else "invalid_input"
    }

    fun updateTransaction(transaction: com.turbank.mobile.data.TransactionEntity) = perform {
        if (repository.updateTransaction(transaction)) "saved" else "invalid_input"
    }

    fun addRecipient(name: String) = perform {
        if (repository.addRecipient(name)) "saved" else "invalid_input"
    }

    fun transfer(fromId: String, toId: String?, recipient: String, amountMinor: Long?, description: String, operationId: String) {
        val amount = amountMinor ?: run { _message.value = "invalid_amount"; return }
        perform {
            when (val result = repository.transfer(operationId, fromId, toId, recipient, amount, description)) {
                is TransferResult.Success -> "transfer_success"
                is TransferResult.Failure -> result.reason
            }
        }
    }


    fun receiveDemoMoney(accountId: String, amountMinor: Long?, sender: String, description: String) {
        val amount = amountMinor ?: run { _message.value = "invalid_amount"; return }
        perform {
            when (val result = repository.receiveDemoMoney(accountId, amount, sender, description)) {
                is TransferResult.Success -> "receive_success"
                is TransferResult.Failure -> result.reason
            }
        }
    }

    fun createGoal(name: String, targetMinor: Long?, currencyCode: String = "EUR") = perform {
        if (targetMinor == null) "invalid_amount"
        else if (repository.createGoal(name, targetMinor, currencyCode)) "saved" else "invalid_input"
    }

    fun contribute(goalId: String, accountId: String, amountMinor: Long?, withdraw: Boolean) {
        val amount = amountMinor ?: run { _message.value = "invalid_amount"; return }
        perform {
            when (val result = repository.contributeToGoal(goalId, accountId, amount, withdraw)) {
                is TransferResult.Success -> "saved"
                is TransferResult.Failure -> result.reason
            }
        }
    }

    fun payBill(billId: String, accountId: String) = perform {
        when (val result = repository.markBillPaid(billId, accountId)) {
            is TransferResult.Success -> "saved"
            is TransferResult.Failure -> result.reason
        }
    }

    fun addCard(name: String, limitMinor: Long?) = perform {
        if (limitMinor == null) "invalid_amount"
        else if (repository.addCard(name, limitMinor)) "saved" else "invalid_input"
    }


    fun simulateCardPayment(cardId: String, accountId: String, amountMinor: Long?, merchant: String, channel: String) {
        val amount = amountMinor ?: run { _message.value = "invalid_amount"; return }
        perform {
            when (val result = repository.simulateCardPayment(cardId, accountId, amount, merchant, channel)) {
                is TransferResult.Success -> "purchase_success"
                is TransferResult.Failure -> result.reason
            }
        }
    }

    fun updateCard(card: VirtualCardEntity) = perform {
        repository.updateCard(card)
        "saved"
    }

    fun deleteCard(id: String) = perform {
        repository.deleteCard(id)
        "saved"
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            notifications.value.firstOrNull { it.id == id }?.let { repository.markNotificationRead(it) }
        }
    }

    fun resetDemoData() = perform {
        repository.resetDemoData()
        "reset_done"
    }

    fun addNotification(title: String, body: String) = perform {
        repository.addNotification(title, body)
        "saved"
    }

    private fun change(block: suspend () -> Unit) {
        viewModelScope.launch {
            try { block() } catch (_: Exception) { _message.value = "generic_error" }
        }
    }

    private fun perform(block: suspend () -> String) {
        if (_working.value) return
        viewModelScope.launch {
            _working.value = true
            try {
                _message.value = block()
            } catch (_: Exception) {
                _message.value = "generic_error"
            } finally {
                _working.value = false
            }
        }
    }

    class Factory(
        private val repository: BankRepository,
        private val preferences: PreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            BankViewModel(repository, preferences) as T
    }
}
