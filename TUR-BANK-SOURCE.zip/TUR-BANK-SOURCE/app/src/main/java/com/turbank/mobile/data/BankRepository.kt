package com.turbank.mobile.data

import androidx.room.withTransaction
import com.turbank.mobile.domain.TransferRules
import kotlinx.coroutines.flow.Flow
import java.util.Calendar
import java.util.UUID

sealed interface TransferResult {
    data class Success(val operationId: String) : TransferResult
    data class Failure(val reason: String) : TransferResult
}

class BankRepository(private val db: BankDatabase) {
    val accounts: Flow<List<AccountEntity>> = db.accounts().observeAll()
    val transactions: Flow<List<TransactionEntity>> = db.transactions().observeAll()
    val recentTransactions: Flow<List<TransactionEntity>> = db.transactions().observeRecent(8)
    val goals: Flow<List<SavingsGoalEntity>> = db.goals().observeAll()
    val budgets: Flow<List<BudgetEntity>> = db.budgets().observeAll()
    val bills: Flow<List<BillEntity>> = db.bills().observeActive()
    val cards: Flow<List<VirtualCardEntity>> = db.cards().observeAll()
    val recipients: Flow<List<RecipientEntity>> = db.recipients().observeAll()
    val notifications: Flow<List<AppNotificationEntity>> = db.notifications().observeAll()

    suspend fun seedIfNeeded() = db.withTransaction {
        if (db.accounts().getAll().isEmpty()) seedRecords()
    }

    private suspend fun seedRecords() {
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val everyday = AccountEntity(id = "seed-everyday", name = "Everyday account", type = "EVERYDAY", balanceMinor = 245050, createdAt = now - 3)
        val savings = AccountEntity(id = "seed-savings", name = "Savings", type = "SAVINGS", balanceMinor = 830000, createdAt = now - 2)
        val shared = AccountEntity(id = "seed-shared", name = "Shared account", type = "SHARED", balanceMinor = 112040, createdAt = now - 1)
        db.accounts().insertAll(listOf(everyday, savings, shared))
        db.transactions().insertAll(listOf(
            TransactionEntity("seed-tx-1", everyday.id, recipient = "TUR BANK Demo Payroll", amountMinor = 320000, direction = "IN", category = "Income", description = "Monthly salary", createdAt = now - day * 2),
            TransactionEntity("seed-tx-2", everyday.id, recipient = "Fresh Market", amountMinor = 5420, direction = "OUT", category = "Groceries", description = "Weekly groceries", createdAt = now - day),
            TransactionEntity("seed-tx-3", everyday.id, recipient = "Corner Coffee", amountMinor = 450, direction = "OUT", category = "Dining", description = "Coffee", createdAt = now - 16 * 3_600_000L),
            TransactionEntity("seed-tx-4", shared.id, recipient = "City Utilities", amountMinor = 8420, direction = "OUT", category = "Bills", description = "Utilities", createdAt = now - day * 3),
            TransactionEntity("seed-tx-5", everyday.id, recipient = "Book House", amountMinor = 2499, direction = "OUT", category = "Shopping", description = "Books", createdAt = now - day * 5),
            TransactionEntity("seed-tx-6", savings.id, recipient = "TUR BANK Demo Payroll", amountMinor = 50000, direction = "IN", category = "Savings", description = "Opening demo contribution", createdAt = now - day * 7)
        ))
        db.recipients().insert(RecipientEntity(id = "seed-rec-1", name = "Alex Morgan", reference = "DEMO-ALEX"))
        db.recipients().insert(RecipientEntity(id = "seed-rec-2", name = "Sam Taylor", reference = "DEMO-SAM"))
        db.goals().insertAll(listOf(
            SavingsGoalEntity(id = "seed-goal-1", name = "Summer trip", targetMinor = 150000, savedMinor = 45000),
            SavingsGoalEntity(id = "seed-goal-2", name = "Emergency fund", targetMinor = 1000000, savedMinor = 830000)
        ))
        db.budgets().insertAll(listOf(
            BudgetEntity(id = "seed-budget-1", category = "Groceries", limitMinor = 30000),
            BudgetEntity(id = "seed-budget-2", category = "Dining", limitMinor = 15000),
            BudgetEntity(id = "seed-budget-3", category = "Shopping", limitMinor = 20000),
            BudgetEntity(id = "seed-budget-4", category = "Bills", limitMinor = 45000)
        ))
        val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 2) }.timeInMillis
        val nextWeek = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis
        db.bills().insertAll(listOf(
            BillEntity(id = "seed-bill-1", name = "Home rent", category = "Housing", amountMinor = 85000, dueAt = tomorrow, recurrence = "MONTHLY"),
            BillEntity(id = "seed-bill-2", name = "Internet", category = "Utilities", amountMinor = 3999, dueAt = nextWeek, recurrence = "MONTHLY"),
            BillEntity(id = "seed-bill-3", name = "Streaming", category = "Subscription", amountMinor = 1299, dueAt = now + day * 10, recurrence = "MONTHLY")
        ))
        db.cards().insert(VirtualCardEntity(id = "seed-card-1", nickname = "Daily card", lastFour = "•• 4821", limitMinor = 150000))
        db.cards().insert(VirtualCardEntity(id = "seed-card-2", nickname = "Online essentials", lastFour = "•• 9057", limitMinor = 50000, contactlessEnabled = false))
        db.notifications().insert(AppNotificationEntity(id = "seed-notice-1", title = "Welcome to TUR BANK", body = "Explore safely with fictional demo data.", createdAt = now))
        db.notifications().insert(AppNotificationEntity(id = "seed-notice-2", title = "Savings insight", body = "Your emergency fund is close to its first milestone.", createdAt = now - day))
    }

    suspend fun resetDemoData() = db.withTransaction {
        db.transactions().clear()
        db.goals().clear()
        db.budgets().clear()
        db.bills().clear()
        db.cards().clear()
        db.recipients().clear()
        db.notifications().clear()
        db.accounts().clear()
        seedRecords()
    }

    suspend fun createAccount(name: String, type: String, currency: String = "EUR"): Boolean {
        if (name.isBlank() || currency.length != 3) return false
        db.accounts().insert(AccountEntity(name = name.trim(), type = type, currencyCode = currency.uppercase()))
        return true
    }

    suspend fun renameAccount(id: String, name: String): Boolean {
        if (name.isBlank()) return false
        val account = db.accounts().getById(id) ?: return false
        db.accounts().update(account.copy(name = name.trim()))
        return true
    }

    suspend fun updateTransaction(transaction: TransactionEntity): Boolean {
        if (transaction.category.isBlank()) return false
        val existing = db.transactions().getById(transaction.id) ?: return false
        db.transactions().update(existing.copy(category = transaction.category.trim(), note = transaction.note.take(300)))
        return true
    }

    suspend fun addRecipient(name: String): Boolean {
        if (name.isBlank()) return false
        db.recipients().insert(RecipientEntity(name = name.trim()))
        return true
    }

    suspend fun transfer(
        operationId: String,
        fromAccountId: String,
        toAccountId: String?,
        recipientName: String,
        amountMinor: Long,
        description: String
    ): TransferResult = db.withTransaction {
        if (operationId.isBlank()) return@withTransaction TransferResult.Failure("invalid_request")
        if (db.transactions().getById("$operationId-out") != null) {
            return@withTransaction TransferResult.Failure("duplicate")
        }
        if (amountMinor <= 0) return@withTransaction TransferResult.Failure("invalid_amount")
        val from = db.accounts().getById(fromAccountId)
            ?: return@withTransaction TransferResult.Failure("source_missing")
        val ownDestination = toAccountId?.let { db.accounts().getById(it) }
        if (toAccountId != null && ownDestination == null) {
            return@withTransaction TransferResult.Failure("destination_missing")
        }
        val label = if (ownDestination != null) ownDestination.name else recipientName.trim()
        val fee = if (ownDestination == null) ((amountMinor * 50L) / 10_000L) else 0L // 0.50% fictional fee.
        val validation = TransferRules.validate(
            fromAccountId = from.id,
            toAccountId = ownDestination?.id,
            fromCurrency = from.currencyCode,
            toCurrency = ownDestination?.currencyCode,
            availableBalanceMinor = from.balanceMinor,
            amountMinor = amountMinor,
            feeMinor = fee,
            recipient = label
        )
        if (validation != null) return@withTransaction TransferResult.Failure(validation)
        val total = amountMinor + fee
        db.accounts().setBalance(from.id, from.balanceMinor - total)
        db.transactions().insert(
            TransactionEntity(
                id = "$operationId-out", accountId = from.id, relatedAccountId = ownDestination?.id,
                recipient = label, amountMinor = total, direction = "OUT",
                category = if (ownDestination == null) "Transfer" else "Own accounts",
                description = description.ifBlank { "Demo transfer" }, operationId = operationId
            )
        )
        if (ownDestination != null) {
            db.accounts().setBalance(ownDestination.id, ownDestination.balanceMinor + amountMinor)
            db.transactions().insert(
                TransactionEntity(
                    id = "$operationId-in", accountId = ownDestination.id, relatedAccountId = from.id,
                    recipient = from.name, amountMinor = amountMinor, direction = "IN",
                    category = "Own accounts", description = description.ifBlank { "Own account transfer" },
                    operationId = operationId
                )
            )
        } else {
            db.notifications().insert(AppNotificationEntity(
                title = "Demo transfer complete",
                body = "A demo payment to $label was recorded. No real money moved."
            ))
        }
        TransferResult.Success(operationId)
    }


    suspend fun receiveDemoMoney(
        accountId: String,
        amountMinor: Long,
        sender: String,
        description: String
    ): TransferResult = db.withTransaction {
        if (amountMinor <= 0) return@withTransaction TransferResult.Failure("invalid_amount")
        val account = db.accounts().getById(accountId)
            ?: return@withTransaction TransferResult.Failure("source_missing")
        val id = UUID.randomUUID().toString()
        db.accounts().setBalance(account.id, account.balanceMinor + amountMinor)
        db.transactions().insert(TransactionEntity(
            id = id, accountId = account.id, recipient = sender.ifBlank { "Demo sender" },
            amountMinor = amountMinor, direction = "IN", category = "Demo income",
            description = description.ifBlank { "Simulated incoming demo payment" },
            operationId = id
        ))
        db.notifications().insert(AppNotificationEntity(
            title = "Demo money received",
            body = "${account.currencyCode} ${(amountMinor / 100.0)} was credited to ${account.name}. No real money moved."
        ))
        TransferResult.Success(id)
    }

    suspend fun createGoal(name: String, targetMinor: Long, currencyCode: String = "EUR"): Boolean {
        if (name.isBlank() || targetMinor <= 0 || currencyCode.length != 3) return false
        db.goals().insert(SavingsGoalEntity(name = name.trim(), targetMinor = targetMinor, currencyCode = currencyCode.uppercase()))
        return true
    }

    suspend fun contributeToGoal(goalId: String, accountId: String, amountMinor: Long, withdraw: Boolean = false): TransferResult =
        db.withTransaction {
            if (amountMinor <= 0) return@withTransaction TransferResult.Failure("invalid_amount")
            val goal = db.goals().getById(goalId) ?: return@withTransaction TransferResult.Failure("goal_missing")
            val account = db.accounts().getById(accountId) ?: return@withTransaction TransferResult.Failure("source_missing")
            if (account.currencyCode != goal.currencyCode) return@withTransaction TransferResult.Failure("currency_mismatch")
            if (withdraw) {
                if (goal.savedMinor < amountMinor) return@withTransaction TransferResult.Failure("goal_insufficient")
                db.goals().update(goal.copy(savedMinor = goal.savedMinor - amountMinor))
                db.accounts().setBalance(account.id, account.balanceMinor + amountMinor)
            } else {
                if (account.balanceMinor < amountMinor) return@withTransaction TransferResult.Failure("insufficient_funds")
                db.goals().update(goal.copy(savedMinor = goal.savedMinor + amountMinor))
                db.accounts().setBalance(account.id, account.balanceMinor - amountMinor)
            }
            val id = UUID.randomUUID().toString()
            db.transactions().insert(TransactionEntity(
                id = id, accountId = account.id, recipient = goal.name, amountMinor = amountMinor,
                direction = if (withdraw) "IN" else "OUT", category = "Savings",
                description = if (withdraw) "Goal withdrawal" else "Goal contribution",
                operationId = id
            ))
            TransferResult.Success(id)
        }

    suspend fun markBillPaid(billId: String, accountId: String): TransferResult = db.withTransaction {
        val bill = db.bills().getById(billId) ?: return@withTransaction TransferResult.Failure("bill_missing")
        if (bill.paid) return@withTransaction TransferResult.Failure("already_paid")
        val account = db.accounts().getById(accountId) ?: return@withTransaction TransferResult.Failure("source_missing")
        if (account.currencyCode != bill.currencyCode) return@withTransaction TransferResult.Failure("currency_mismatch")
        if (account.balanceMinor < bill.amountMinor) return@withTransaction TransferResult.Failure("insufficient_funds")
        db.accounts().setBalance(account.id, account.balanceMinor - bill.amountMinor)
        db.bills().update(bill.copy(paid = true))
        val id = "bill-${bill.id}-${System.currentTimeMillis()}"
        db.transactions().insert(TransactionEntity(
            id = id, accountId = account.id, recipient = bill.name, amountMinor = bill.amountMinor,
            direction = "OUT", category = bill.category, description = "Demo bill payment",
            operationId = "bill-${bill.id}"
        ))
        db.notifications().insert(AppNotificationEntity(title = "Bill marked paid", body = "${bill.name} was paid in demo mode."))
        TransferResult.Success(id)
    }


    suspend fun simulateCardPayment(
        cardId: String,
        accountId: String,
        amountMinor: Long,
        merchant: String,
        channel: String
    ): TransferResult = db.withTransaction {
        val card = db.cards().getById(cardId) ?: return@withTransaction TransferResult.Failure("source_missing")
        val account = db.accounts().getById(accountId) ?: return@withTransaction TransferResult.Failure("source_missing")
        if (card.frozen) return@withTransaction TransferResult.Failure("card_frozen")
        if (merchant.isBlank()) return@withTransaction TransferResult.Failure("merchant_required")
        if (amountMinor <= 0) return@withTransaction TransferResult.Failure("invalid_amount")
        val enabled = when (channel) {
            "ONLINE" -> card.onlineEnabled
            "CONTACTLESS" -> card.contactlessEnabled
            "ATM" -> card.atmEnabled
            else -> false
        }
        if (!enabled) return@withTransaction TransferResult.Failure("card_payment_disabled")
        if (account.currencyCode != card.currencyCode) return@withTransaction TransferResult.Failure("currency_mismatch")
        if (card.spentMinor + amountMinor > card.limitMinor) return@withTransaction TransferResult.Failure("card_limit")
        if (account.balanceMinor < amountMinor) return@withTransaction TransferResult.Failure("insufficient_funds")
        db.accounts().setBalance(account.id, account.balanceMinor - amountMinor)
        db.cards().update(card.copy(spentMinor = card.spentMinor + amountMinor))
        val id = UUID.randomUUID().toString()
        db.transactions().insert(TransactionEntity(
            id = id, accountId = account.id, recipient = merchant.trim(), amountMinor = amountMinor,
            direction = "OUT", category = "Card payment", description = "Simulated $channel purchase",
            operationId = id
        ))
        db.notifications().insert(AppNotificationEntity(
            title = "Demo card payment",
            body = "${account.currencyCode} ${(amountMinor / 100.0)} at ${merchant.trim()} was recorded in demo mode."
        ))
        TransferResult.Success(id)
    }

    suspend fun addCard(nickname: String, limitMinor: Long): Boolean {
        if (nickname.isBlank() || limitMinor <= 0) return false
        val four = (1000..9999).random().toString()
        db.cards().insert(VirtualCardEntity(nickname = nickname.trim(), lastFour = "•• $four", limitMinor = limitMinor))
        return true
    }

    suspend fun updateCard(card: VirtualCardEntity) = db.cards().update(card)
    suspend fun deleteCard(id: String) = db.cards().delete(id)

    suspend fun markNotificationRead(item: AppNotificationEntity) = db.notifications().update(item.copy(isRead = true))
    suspend fun addNotification(title: String, body: String) =
        db.notifications().insert(AppNotificationEntity(title = title, body = body))
}
