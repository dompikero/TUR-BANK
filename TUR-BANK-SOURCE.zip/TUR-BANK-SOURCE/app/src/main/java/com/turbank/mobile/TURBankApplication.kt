package com.turbank.mobile

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import com.turbank.mobile.data.BankDatabase
import com.turbank.mobile.data.BankRepository
import com.turbank.mobile.data.PreferencesRepository

private val Context.userSettingsDataStore by preferencesDataStore(name = "tur_bank_settings")

class TURBankApplication : Application() {
    val database by lazy { BankDatabase.get(this) }
    val repository by lazy { BankRepository(database) }
    val preferences by lazy { PreferencesRepository(userSettingsDataStore) }
}
