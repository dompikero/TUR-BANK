package com.turbank.mobile.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class UserSettings(
    val language: String = "",
    val theme: String = "system",
    val showBalances: Boolean = true,
    val displayCurrency: String = "EUR",
    val notificationsEnabled: Boolean = true,
    val biometricPreference: Boolean = false,
    val lockOnRestart: Boolean = true,
    val onboardingComplete: Boolean = false
)

class PreferencesRepository(private val store: DataStore<Preferences>) {
    private object Keys {
        val language = stringPreferencesKey("language")
        val theme = stringPreferencesKey("theme")
        val showBalances = booleanPreferencesKey("show_balances")
        val currency = stringPreferencesKey("display_currency")
        val notifications = booleanPreferencesKey("notifications_enabled")
        val biometrics = booleanPreferencesKey("biometric_preference")
        val lockOnRestart = booleanPreferencesKey("lock_on_restart")
        val onboardingComplete = booleanPreferencesKey("onboarding_complete")
    }

    val settings: Flow<UserSettings> = store.data.map { prefs ->
        UserSettings(
            language = prefs[Keys.language] ?: "",
            theme = prefs[Keys.theme] ?: "system",
            showBalances = prefs[Keys.showBalances] ?: true,
            displayCurrency = prefs[Keys.currency] ?: "EUR",
            notificationsEnabled = prefs[Keys.notifications] ?: true,
            biometricPreference = prefs[Keys.biometrics] ?: false,
            lockOnRestart = prefs[Keys.lockOnRestart] ?: true,
            onboardingComplete = prefs[Keys.onboardingComplete] ?: false
        )
    }

    suspend fun setLanguage(value: String) { store.edit { it[Keys.language] = value } }
    suspend fun setTheme(value: String) { store.edit { it[Keys.theme] = value } }
    suspend fun setShowBalances(value: Boolean) { store.edit { it[Keys.showBalances] = value } }
    suspend fun setCurrency(value: String) { store.edit { it[Keys.currency] = value } }
    suspend fun setNotifications(value: Boolean) { store.edit { it[Keys.notifications] = value } }
    suspend fun setBiometrics(value: Boolean) { store.edit { it[Keys.biometrics] = value } }
    suspend fun setLockOnRestart(value: Boolean) { store.edit { it[Keys.lockOnRestart] = value } }
    suspend fun setOnboardingComplete(value: Boolean) { store.edit { it[Keys.onboardingComplete] = value } }
}
