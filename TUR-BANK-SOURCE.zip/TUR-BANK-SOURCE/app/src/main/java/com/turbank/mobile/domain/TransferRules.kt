package com.turbank.mobile.domain

object TransferRules {
    fun validate(
        fromAccountId: String,
        toAccountId: String?,
        fromCurrency: String,
        toCurrency: String?,
        availableBalanceMinor: Long,
        amountMinor: Long,
        feeMinor: Long,
        recipient: String
    ): String? {
        if (amountMinor <= 0) return "invalid_amount"
        if (toAccountId != null && fromAccountId == toAccountId) return "same_account"
        if (toAccountId != null && fromCurrency != toCurrency) return "currency_mismatch"
        if (recipient.isBlank()) return "recipient_missing"
        if (availableBalanceMinor < amountMinor + feeMinor) return "insufficient_funds"
        return null
    }
}
