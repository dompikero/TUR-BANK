package com.turbank.mobile.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: String,
    val currencyCode: String = "EUR",
    val balanceMinor: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "transactions",
    indices = [Index("accountId"), Index("createdAt"), Index("operationId")],
    foreignKeys = [ForeignKey(
        entity = AccountEntity::class,
        parentColumns = ["id"],
        childColumns = ["accountId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class TransactionEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val relatedAccountId: String? = null,
    val recipient: String,
    val amountMinor: Long,
    /** IN, OUT, or INFO. amountMinor is always non-negative. */
    val direction: String,
    val category: String,
    val description: String,
    val createdAt: Long = System.currentTimeMillis(),
    val status: String = "COMPLETED",
    val note: String = "",
    val operationId: String? = null
)

@Entity(tableName = "recipients")
data class RecipientEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val reference: String = "DEMO-" + UUID.randomUUID().toString().take(6).uppercase(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val targetMinor: Long,
    val currencyCode: String = "EUR",
    val savedMinor: Long = 0,
    val targetDate: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets", indices = [Index("category")])
data class BudgetEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val category: String,
    val limitMinor: Long,
    val period: String = "MONTH"
)

@Entity(tableName = "bills", indices = [Index("dueAt")])
data class BillEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String,
    val amountMinor: Long,
    val currencyCode: String = "EUR",
    val dueAt: Long,
    val recurrence: String = "MONTHLY",
    val paid: Boolean = false,
    val active: Boolean = true
)

@Entity(tableName = "virtual_cards")
data class VirtualCardEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val nickname: String,
    val lastFour: String,
    val currencyCode: String = "EUR",
    val frozen: Boolean = false,
    val limitMinor: Long = 50000,
    val spentMinor: Long = 0,
    val onlineEnabled: Boolean = true,
    val contactlessEnabled: Boolean = true,
    val atmEnabled: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_notifications", indices = [Index("createdAt")])
data class AppNotificationEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
