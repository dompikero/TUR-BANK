# TUR BANK demo app: add app-specific keep rules here if minification is enabled.
